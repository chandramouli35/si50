<?php
/**
 * SecondInnings50 - Premium Razorpay Payment Gateway Pipeline
 * Handles order creation, client-side signature verification, and webhook dispatches.
 *
 * @package SecondInnings50
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Check if user is a premium membership status
 */
function si50_is_premium( $user_id ) {
	// Administrator is always premium
	if ( user_can( $user_id, 'manage_options' ) ) {
		return true;
	}
	$status = get_user_meta( $user_id, 'si50_membership_status', true );
	return ( 'premium' === $status );
}

/**
 * Retrieve active Razorpay Credential Options
 */
function si50_get_razorpay_credentials() {
	return array(
		'key_id'     => si50_get_razorpay_key_id(),
		'key_secret' => si50_get_razorpay_secret(),
	);
}

/**
 * AJAX hook to create a Razorpay Order ID
 */
function si50_ajax_razorpay_create_order() {
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Please log in to upgrade membership.', 'secondinnings50' ) ) );
	}

	check_ajax_referer( 'si50_auth_nonce', 'security' );

	$user_id  = get_current_user_id();
	$userdata = get_userdata( $user_id );
	
	// Price: ₹99 INR (specified in Paise: 9900)
	$amount_paise = 9900;
	$receipt_id   = 'si50_rcpt_' . $user_id . '_' . time();

	$creds = si50_get_razorpay_credentials();

	// Create order call via Razorpay API
	$url = 'https://api.razorpay.com/v1/orders';
	
	$response = wp_remote_post( $url, array(
		'method'      => 'POST',
		'timeout'     => 10,
		'headers'     => array(
			'Authorization' => 'Basic ' . base64_encode( $creds['key_id'] . ':' . $creds['key_secret'] ),
			'Content-Type'  => 'application/json',
		),
		'body'        => json_encode( array(
			'amount'          => $amount_paise,
			'currency'        => 'INR',
			'receipt'         => $receipt_id,
			'payment_capture' => 1, // Auto-capture payments
			'notes'           => array(
				'user_id'    => strval( $user_id ),
				'user_email' => $userdata->user_email,
				'purpose'    => 'SecondInnings50 Premium Verification Fee'
			)
		) )
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => $response->get_error_message() ) );
	}

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( isset( $data['error'] ) ) {
		wp_send_json_error( array( 'message' => $data['error']['description'] ) );
	}

	// Log telemetry order
	si50_log_activity( $user_id, 'payment_order_created', sprintf( 'Razorpay Order Created: %s. Amount: ₹99', $data['id'] ) );

	wp_send_json_success( array(
		'key_id'       => $creds['key_id'],
		'order_id'     => $data['id'],
		'amount'       => $amount_paise,
		'currency'     => 'INR',
		'name'         => get_bloginfo( 'name' ),
		'description'  => esc_html__( 'Onboarding Identity Verification Fee Contribution', 'secondinnings50' ),
		'prefill'      => array(
			'name'  => get_user_meta( $user_id, 'si50_fullname', true ),
			'email' => $userdata->user_email,
			'contact'=> get_user_meta( $user_id, 'si50_phone', true ),
		)
	) );
}
add_action( 'wp_ajax_si50_razorpay_create_order', 'si50_ajax_razorpay_create_order' );

/**
 * AJAX hook to verify Razorpay checkout signature callback
 */
function si50_ajax_verify_razorpay_payment() {
	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Please log in to verify payments.', 'secondinnings50' ) ) );
	}

	check_ajax_referer( 'si50_auth_nonce', 'security' );

	$user_id = get_current_user_id();

	$razorpay_payment_id = isset( $_POST['razorpay_payment_id'] ) ? sanitize_text_field( $_POST['razorpay_payment_id'] ) : '';
	$razorpay_order_id   = isset( $_POST['razorpay_order_id'] ) ? sanitize_text_field( $_POST['razorpay_order_id'] ) : '';
	$razorpay_signature  = isset( $_POST['razorpay_signature'] ) ? sanitize_text_field( $_POST['razorpay_signature'] ) : '';

	if ( empty( $razorpay_payment_id ) || empty( $razorpay_order_id ) || empty( $razorpay_signature ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Invalid payment arguments.', 'secondinnings50' ) ) );
	}

	$creds = si50_get_razorpay_credentials();

	// Server-side SHA256 HMAC Signature Verification
	$expected_signature = hash_hmac( 'sha256', $razorpay_order_id . '|' . $razorpay_payment_id, $creds['key_secret'] );

	if ( hash_equals( $expected_signature, $razorpay_signature ) ) {
		// Verify complete: update membership status instantly to premium
		update_user_meta( $user_id, 'si50_membership_status', 'Paid/Pending Approval' );

		// Record transaction details
		update_user_meta( $user_id, 'si50_razorpay_payment_id', $razorpay_payment_id );
		update_user_meta( $user_id, 'si50_razorpay_order_id', $razorpay_order_id );

		si50_log_activity( $user_id, 'payment_verified', sprintf( 'Razorpay Signature Verified: %s. Upgraded to Paid/Pending Approval.', $razorpay_payment_id ) );

		wp_send_json_success( array( 
			'message'  => esc_html__( 'Payment verified! Your account is now Paid/Pending Approval.', 'secondinnings50' ),
			'redirect' => home_url( '/payment/success/' )
		) );
	} else {
		si50_log_activity( $user_id, 'payment_failed', 'Razorpay signature verification check failed.' );
		wp_send_json_error( array( 'message' => esc_html__( 'Cryptographic signature mismatch. Verification failed.', 'secondinnings50' ) ) );
	}
}
add_action( 'wp_ajax_si50_verify_razorpay_payment', 'si50_ajax_verify_razorpay_payment' );

/**
 * 3. Server-Side Webhook Listener Endpoint
 */
function si50_register_razorpay_webhook_listener() {
	// Capture custom query parameter to handle webhooks directly (bypass AJAX wrappers)
	if ( isset( $_GET['si50_action'] ) && 'razorpay_webhook' === $_GET['si50_action'] ) {
		$post_body = file_get_contents( 'php://input' );
		$signature = isset( $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ) ? sanitize_text_field( $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ) : '';

		if ( empty( $post_body ) || empty( $signature ) ) {
			status_header( 400 );
			echo 'Missing payload or signature.';
			exit;
		}

		$webhook_secret = si50_get_razorpay_webhook_secret();

		// Verify signature
		$expected_signature = hash_hmac( 'sha256', $post_body, $webhook_secret );

		if ( hash_equals( $expected_signature, $signature ) ) {
			$data = json_decode( $post_body, true );
			
			if ( $data && isset( $data['event'] ) ) {
				$event = $data['event'];
				
				// Handle payment capture / order paid events
				if ( 'order.paid' === $event || 'payment.captured' === $event ) {
					$payload = isset( $data['payload']['payment']['entity'] ) ? $data['payload']['payment']['entity'] : array();
					if ( empty( $payload ) && isset( $data['payload']['order']['entity'] ) ) {
						$payload = $data['payload']['order']['entity'];
					}

					// Extract user_id from notes
					$user_id = isset( $payload['notes']['user_id'] ) ? intval( $payload['notes']['user_id'] ) : 0;
					$order_id = isset( $payload['order_id'] ) ? sanitize_text_field( $payload['order_id'] ) : '';
					$payment_id = isset( $payload['id'] ) ? sanitize_text_field( $payload['id'] ) : '';

					if ( $user_id ) {
						update_user_meta( $user_id, 'si50_membership_status', 'Paid/Pending Approval' );
						if ( ! empty( $payment_id ) ) {
							update_user_meta( $user_id, 'si50_razorpay_payment_id', $payment_id );
						}
						if ( ! empty( $order_id ) ) {
							update_user_meta( $user_id, 'si50_razorpay_order_id', $order_id );
						}

						si50_log_activity( $user_id, 'payment_webhook_received', sprintf( 'Razorpay Webhook: Event %s. Verified Order: %s. Upgraded user to Paid/Pending Approval.', $event, $order_id ) );
					}
				}
			}

			status_header( 200 );
			echo 'Webhook processed successfully.';
			exit;
		} else {
			error_log( 'SecondInnings50 Payment Error: Razorpay Webhook signature verification mismatch.' );
			status_header( 401 );
			echo 'Signature verification failed.';
			exit;
		}
	}
}
add_action( 'template_redirect', 'si50_register_razorpay_webhook_listener' );

/**
 * 4. Render Payment Gate Section UI helper
 */
function si50_render_payment_gate_section( $user_id ) {
	$m_gender = get_user_meta( $user_id, 'si50_gender', true );
	$is_premium = si50_is_premium( $user_id );

	if ( $is_premium ) {
		return;
	}

	// In the launching strategy: Women are free premium, Men require a vetting contribution fee
	if ( 'Female' === $m_gender ) {
		return;
	}
	?>
	<div class="card" style="border: 2px solid var(--color-gold) !important; background-color: #FFFFFF !important; margin-bottom: 24px; padding: 20px; border-radius: var(--radius-md); text-align: center; box-shadow: 0 4px 15px rgba(197, 160, 89, 0.1);">
		<span style="font-size: 2.5rem; display: block; margin-bottom: 10px;">💳</span>
		<h3 style="font-family: var(--font-serif); font-weight: 700; color: var(--color-forest); margin: 0 0 10px 0;">
			<?php esc_html_e( 'Onboarding Identity Verification Fee Contribution', 'secondinnings50' ); ?>
		</h3>
		<p style="color: var(--color-charcoal-muted); font-size: var(--fs-sm); max-width: 500px; margin: 0 auto 16px auto; line-height: 1.5;">
			<?php esc_html_e( 'Men membership accounts require a nominal identity verification contribution fee of ₹99 INR. This helps support manual background checks and keeps the community gated, authentic, and safe.', 'secondinnings50' ); ?>
		</p>
		
		<div style="font-size: 1.5rem; font-weight: 800; color: var(--color-terracotta); margin-bottom: 8px;">
			₹99 <span style="font-size: 0.85rem; font-weight: 600; color: var(--color-charcoal-muted);"><?php esc_html_e( 'One-Time Contribution', 'secondinnings50' ); ?></span>
		</div>
		<p style="font-size: 0.85rem; color: var(--color-forest-dark); margin: 0 auto 16px auto; max-width: 500px; line-height: 1.4;">
			<?php esc_html_e( 'This is a One-Time Registration & Verification Fee only. Community access is available only after successful verification and activation of the selected membership plan.', 'secondinnings50' ); ?>
		</p>

		<button type="button" class="btn btn-primary" id="si50-razorpay-trigger-btn" style="padding: 12px 30px; font-weight: 700; font-size: var(--fs-xs);">
			<?php esc_html_e( 'Pay Verification Contribution (Razorpay / UPI)', 'secondinnings50' ); ?>
		</button>

		<div style="margin-top: 15px; font-size: 0.85rem; color: var(--color-charcoal-muted);">
			By proceeding, you agree to our <a href="<?php echo esc_url( home_url( '/terms-and-conditions/' ) ); ?>" target="_blank" style="text-decoration: underline; color: inherit;">Terms & Conditions</a>, <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>" target="_blank" style="text-decoration: underline; color: inherit;">Privacy Policy</a>, and <a href="<?php echo esc_url( home_url( '/refund-policy/' ) ); ?>" target="_blank" style="text-decoration: underline; color: inherit;">Refund Policy</a>.
		</div>
	</div>
	<?php
}
