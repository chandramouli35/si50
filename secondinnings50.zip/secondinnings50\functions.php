<?php
/**
 * SecondInnings50 Theme Functions and Definitions
 *
 * @package SecondInnings50
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Staging/Testing OTP Bypass Framework Switch
if ( ! defined( 'SI50_OTP_BYPASS' ) ) {
	define( 'SI50_OTP_BYPASS', true );
}


/**
 * Setup SecondInnings50 theme defaults and registers support for various WordPress features.
 */
function secondinnings50_setup() {
	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// Enable support for Post Thumbnails on posts and pages.
	add_theme_support( 'post-thumbnails' );

	// Register Navigation Menus.
	register_nav_menus( array(
		'menu-1' => esc_html__( 'Primary Header Menu', 'secondinnings50' ),
	) );

	// Switch default core markup for search form, comment form, etc. to output valid HTML5.
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );

	// Add support for Custom Logo.
	add_theme_support( 'custom-logo', array(
		'height'      => 250,
		'width'       => 250,
		'flex-width'  => true,
		'flex-height' => true,
	) );
}
add_action( 'after_setup_theme', 'secondinnings50_setup' );

/**
 * Enqueue scripts and styles.
 */
function secondinnings50_scripts() {
	// Enqueue Google Fonts
	wp_enqueue_style( 'secondinnings50-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800&display=swap', array(), null );

	// Enqueue main stylesheet (style.css) with cache-busting
	$style_ver = file_exists( get_template_directory() . '/style.css' ) ? filemtime( get_template_directory() . '/style.css' ) : '1.2.0';
	wp_enqueue_style( 'secondinnings50-style', get_stylesheet_uri(), array( 'secondinnings50-fonts' ), $style_ver );

	// Enqueue main javascript (app.js) in the footer with cache-busting
	$js_ver = file_exists( get_template_directory() . '/app.js' ) ? filemtime( get_template_directory() . '/app.js' ) : '1.0.0';
	wp_enqueue_script( 'secondinnings50-script', get_template_directory_uri() . '/app.js', array(), $js_ver, true );
	
	// Localize AJAX url and nonce for app.js to use enqueued variables instead of hardcoded paths
	wp_localize_script( 'secondinnings50-script', 'si50_ajax', array(
		'ajax_url'   => admin_url( 'admin-ajax.php' ),
		'nonce'      => wp_create_nonce( 'si50_auth_nonce' ),
		'otp_bypass' => defined( 'SI50_OTP_BYPASS' ) ? SI50_OTP_BYPASS : false,
	) );
}
add_action( 'wp_enqueue_scripts', 'secondinnings50_scripts' );

/**
 * Automatically bind custom templates for specific page slugs if they aren't assigned.
 * Hardened with absolute root routing and priority override to bypass GoDaddy layout caching.
 */
function si50_force_custom_page_templates( $template ) {
	$theme_path = defined( 'TEMPLATEPATH' ) ? TEMPLATEPATH : get_stylesheet_directory();

	if ( is_page( 'application-received' ) || ( isset( $_SERVER['REQUEST_URI'] ) && strpos( $_SERVER['REQUEST_URI'], '/application-received/' ) !== false ) ) {
		$custom_template = $theme_path . '/page-application-received.php';
		if ( file_exists( $custom_template ) ) {
			global $wp_query;
			if ( isset( $wp_query ) && $wp_query->is_404 ) {
				$wp_query->is_404 = false;
				status_header( 200 );
			}
			return $custom_template;
		}
	}

	if ( is_page( 'about-us' ) || is_page( 'about' ) ) {
		$custom_template = $theme_path . '/page-about.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'join-application' ) || is_page( 'join' ) ) {
		$custom_template = $theme_path . '/page-join.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'contact-us' ) || is_page( 'contact' ) ) {
		$custom_template = $theme_path . '/page-contact.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'privacy-policy' ) || is_page( 'privacy' ) ) {
		$custom_template = $theme_path . '/page-privacy.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'terms-and-conditions' ) || is_page( 'terms' ) ) {
		$custom_template = $theme_path . '/page-terms.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'directory' ) || is_page( 'members' ) ) {
		$custom_template = $theme_path . '/page-directory.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'profile' ) || is_page( 'my-profile' ) ) {
		$custom_template = $theme_path . '/page-profile.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	if ( is_page( 'notifications' ) ) {
		$custom_template = $theme_path . '/page-notifications.php';
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}
	}
	return $template;
}
add_filter( 'template_include', 'si50_force_custom_page_templates', 99 );

/**
 * AJAX Lead Submission Handler (Homepage Form)
 */
function si50_handle_lead_submission() {
	global $wpdb;

	$name        = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
	$email       = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
	$phone       = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
	$gender      = isset( $_POST['gender'] ) ? sanitize_text_field( $_POST['gender'] ) : '';
	$age_bracket = isset( $_POST['age_bracket'] ) ? sanitize_text_field( $_POST['age_bracket'] ) : '';

	// Separate required empty fields check from invalid formats check
	if ( empty( $name ) || empty( $_POST['email'] ) || empty( $phone ) || empty( $gender ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Required fields are missing.', 'secondinnings50' ) ) );
	}

	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Please enter a valid email address.', 'secondinnings50' ) ) );
	}

	// Store request in the database
	$table_inv = $wpdb->prefix . 'si50_invitation_requests';
	$wpdb->insert(
		$table_inv,
		array(
			'name'        => $name,
			'email'       => $email,
			'phone'       => $phone,
			'gender'      => $gender,
			'age_bracket' => $age_bracket,
			'timestamp'   => current_time( 'mysql' )
		),
		array( '%s', '%s', '%s', '%s', '%s', '%s' )
	);

	$admin_email = get_option( 'admin_email' );
	$subject     = sprintf( '[%s] New Invitation Request', get_bloginfo( 'name' ) );
	
	$body  = "You have received a new invitation request:\n\n";
	$body .= "Name: " . $name . "\n";
	$body .= "Email: " . $email . "\n";
	$body .= "Phone: " . $phone . "\n";
	$body .= "Gender: " . $gender . "\n";
	$body .= "Age Bracket: " . $age_bracket . "\n";

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'From: ' . get_bloginfo( 'name' ) . ' <' . $admin_email . '>'
	);

	// Log submission for testing/diagnosis backup
	error_log( sprintf( 'SecondInnings50 [Lead Submission] - Name: %s, Email: %s, Phone: %s, Gender: %s, Age Bracket: %s', $name, $email, $phone, $gender, $age_bracket ) );

	wp_mail( $admin_email, $subject, $body, $headers );
	wp_send_json_success( array( 'message' => esc_html__( 'Thank you! Your request has been received.', 'secondinnings50' ) ) );
}
add_action( 'wp_ajax_si50_submit_lead', 'si50_handle_lead_submission' );
add_action( 'wp_ajax_nopriv_si50_submit_lead', 'si50_handle_lead_submission' );

/**
 * AJAX Onboarding Application Submission Handler (Join Form)
 */
function si50_handle_join_submission() {
	$name           = isset( $_POST['fullname'] ) ? sanitize_text_field( $_POST['fullname'] ) : '';
	$email          = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
	$phone          = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
	$city_state     = isset( $_POST['city_state'] ) ? sanitize_text_field( $_POST['city_state'] ) : ( isset( $_POST['city'] ) ? sanitize_text_field( $_POST['city'] ) : '' );
	$age            = isset( $_POST['age_bracket'] ) ? sanitize_text_field( $_POST['age_bracket'] ) : '';
	$dob            = isset( $_POST['dob'] ) ? sanitize_text_field( $_POST['dob'] ) : '';
	$gender         = isset( $_POST['gender'] ) ? sanitize_text_field( $_POST['gender'] ) : '';
	$marital_status = isset( $_POST['marital_status'] ) ? sanitize_text_field( $_POST['marital_status'] ) : '';
	$occupation     = isset( $_POST['occupation'] ) ? sanitize_text_field( $_POST['occupation'] ) : '';
	$intro          = isset( $_POST['introduction'] ) ? sanitize_textarea_field( $_POST['introduction'] ) : '';
	$emergency_phone = isset( $_POST['emergency_phone'] ) ? sanitize_text_field( $_POST['emergency_phone'] ) : '';

	// Looking For Options
	$looking_for     = isset( $_POST['looking_for'] ) ? $_POST['looking_for'] : array();
	$looking_for_str = is_array( $looking_for ) ? implode( ', ', array_map( 'sanitize_text_field', $looking_for ) ) : sanitize_text_field( $looking_for );

	// Circles Onboarding Flags
	$circles_interest     = isset( $_POST['circles_interest'] ) ? $_POST['circles_interest'] : array();
	$circles_interest_str = is_array( $circles_interest ) ? implode( ', ', array_map( 'sanitize_text_field', $circles_interest ) ) : sanitize_text_field( $circles_interest );

	// Travel Matrix - Destinations
	$travel_dest     = isset( $_POST['travel_destinations'] ) ? $_POST['travel_destinations'] : array();
	$travel_dest_str = is_array( $travel_dest ) ? implode( ', ', array_map( 'sanitize_text_field', $travel_dest ) ) : sanitize_text_field( $travel_dest );

	// Travel Style Profile
	$travel_styles     = isset( $_POST['travel_styles'] ) ? $_POST['travel_styles'] : array();
	$travel_styles_str = is_array( $travel_styles ) ? implode( ', ', array_map( 'sanitize_text_field', $travel_styles ) ) : sanitize_text_field( $travel_styles );

	// Companion Style Match
	$companion_styles = isset( $_POST['companion_styles'] ) ? sanitize_text_field( $_POST['companion_styles'] ) : '';

	// Backward Compatibility/Fallback Fields
	$location     = isset( $_POST['location_preference'] ) ? sanitize_text_field( $_POST['location_preference'] ) : '';
	$relationship = isset( $_POST['relationship_preference'] ) ? sanitize_text_field( $_POST['relationship_preference'] ) : '';

	$interests = isset( $_POST['interests'] ) ? $_POST['interests'] : array();
	$interests_str = is_array( $interests ) ? implode( ', ', array_map( 'sanitize_text_field', $interests ) ) : sanitize_text_field( $interests );

	// Separate required empty fields check from invalid formats check
	if ( empty( $name ) || empty( $_POST['email'] ) || empty( $phone ) || empty( $city_state ) || empty( $emergency_phone ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Required fields are missing.', 'secondinnings50' ) ) );
	}

	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Please enter a valid email address.', 'secondinnings50' ) ) );
	}

	$admin_email = get_option( 'admin_email' );
	$subject     = sprintf( '[%s] New Member Onboarding Application', get_bloginfo( 'name' ) );

	$body  = "A new membership application has been received:\n\n";
	$body .= "=== PERSONAL IDENTITY ===\n";
	$body .= "Name: " . $name . "\n";
	$body .= "Date of Birth: " . $dob . "\n";
	$body .= "Gender: " . $gender . "\n";
	$body .= "Marital Status: " . $marital_status . "\n";
	$body .= "Occupation: " . $occupation . "\n\n";

	$body .= "=== SECURE CONTACT ===\n";
	$body .= "Email: " . $email . "\n";
	$body .= "Phone (WhatsApp): " . $phone . "\n";
	$body .= "City & State: " . $city_state . "\n\n";

	$body .= "=== SAFETY & EMERGENCY ===\n";
	$body .= "Emergency Contact: " . $emergency_phone . "\n\n";

	$body .= "=== PLATFORM MATCHING FLAGS ===\n";
	$body .= "Looking For: " . ( ! empty( $looking_for_str ) ? $looking_for_str : $relationship ) . "\n";
	$body .= "Circles Interest: " . $circles_interest_str . "\n\n";

	$body .= "=== TRAVEL MATRIX SELECTION ===\n";
	$body .= "Travel Destinations: " . $travel_dest_str . "\n";
	$body .= "Travel Styles: " . $travel_styles_str . "\n";
	$body .= "Companion Style Match: " . $companion_styles . "\n\n";

	if ( ! empty( $location ) || ! empty( $interests_str ) ) {
		$body .= "=== LEGACY FIELDS ===\n";
		$body .= "Location Preference: " . $location . "\n";
		$body .= "Interests Selected: " . $interests_str . "\n\n";
	}

	$body .= "=== ABOUT ME / INTRODUCTION ===\n";
	$body .= $intro . "\n";

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'From: ' . get_bloginfo( 'name' ) . ' <' . $admin_email . '>'
	);

	// Log submission for testing/diagnosis backup
	error_log( sprintf( 'SecondInnings50 [Join Submission] - Name: %s, Email: %s, Phone: %s, Gender: %s', $name, $email, $phone, $gender ) );

	wp_mail( $admin_email, $subject, $body, $headers );
	wp_send_json_success( array( 'message' => esc_html__( 'Application submitted successfully.', 'secondinnings50' ) ) );
}
add_action( 'wp_ajax_si50_submit_join', 'si50_handle_join_submission' );
add_action( 'wp_ajax_nopriv_si50_submit_join', 'si50_handle_join_submission' );

/**
 * AJAX Contact Support Submission Handler (Contact Form)
 */
function si50_handle_contact_submission() {
	global $wpdb;
	$name           = isset( $_POST['fullname'] ) ? sanitize_text_field( $_POST['fullname'] ) : '';
	$email          = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
	$phone          = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
	$inquiry_nature = isset( $_POST['inquiry_nature'] ) ? sanitize_text_field( $_POST['inquiry_nature'] ) : '';
	$message        = isset( $_POST['message'] ) ? sanitize_textarea_field( $_POST['message'] ) : '';

	// Separate required empty fields check from invalid formats check
	if ( empty( $name ) || empty( $_POST['email'] ) || empty( $message ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Required fields are missing.', 'secondinnings50' ) ) );
	}

	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => esc_html__( 'Please enter a valid email address.', 'secondinnings50' ) ) );
	}

	// Insert into custom database table
	$wpdb->insert(
		$wpdb->prefix . 'si50_contact_inquiries',
		array(
			'name'           => $name,
			'email'          => $email,
			'phone'          => $phone,
			'inquiry_nature' => $inquiry_nature,
			'message'        => $message,
			'timestamp'      => current_time( 'mysql' ),
		),
		array( '%s', '%s', '%s', '%s', '%s', '%s' )
	);

	$admin_email = get_option( 'admin_email' );
	$subject     = sprintf( '[%s] New Support Message - %s', get_bloginfo( 'name' ), $inquiry_nature );

	$body  = "You have received a new customer support message:\n\n";
	$body .= "Name: " . $name . "\n";
	$body .= "Email: " . $email . "\n";
	$body .= "Phone (WhatsApp): " . $phone . "\n";
	$body .= "Nature of Inquiry: " . $inquiry_nature . "\n\n";
	$body .= "Message:\n" . $message . "\n";

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'From: ' . get_bloginfo( 'name' ) . ' <' . $admin_email . '>'
	);

	// Log submission for testing/diagnosis backup
	error_log( sprintf( 'SecondInnings50 [Contact Submission] - Name: %s, Email: %s, Phone: %s, Nature of Inquiry: %s', $name, $email, $phone, $inquiry_nature ) );

	wp_mail( $admin_email, $subject, $body, $headers );
	wp_send_json_success( array( 'message' => esc_html__( 'Thank you. Your inquiry has been securely routed to our verification hosts. We will contact you shortly.', 'secondinnings50' ) ) );
}
add_action( 'wp_ajax_si50_submit_contact', 'si50_handle_contact_submission' );
add_action( 'wp_ajax_nopriv_si50_submit_contact', 'si50_handle_contact_submission' );

/**
 * Filter wp_nav_menu links to resolve anchor tags on subpages.
 * If we are on a page other than the front page or home page, we prepend the home URL
 * to any custom relative anchor links (e.g., #about, #offerings) so they route back to the homepage correctly.
 */
function si50_nav_menu_anchor_links( $atts, $item, $args ) {
	if ( ! is_front_page() && ! is_home() ) {
		if ( isset( $atts['href'] ) ) {
			$href = $atts['href'];
			// Check if the URL starts with '#'
			if ( strpos( $href, '#' ) === 0 ) {
				$atts['href'] = home_url( '/' ) . $href;
			} elseif ( preg_match( '/^\/[a-zA-Z0-9_\-]*#/', $href ) ) {
				// If it starts with a slash and contains hash (e.g. /#about), make it absolute to avoid subfolder path issues
				$atts['href'] = home_url( $href );
			}
		}
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'si50_nav_menu_anchor_links', 10, 3 );

/**
 * Include Milestone 2 Custom Profile and Vetting Engines
 */
require_once get_template_directory() . '/inc/environment-registry.php';
require_once get_template_directory() . '/inc/auth-profile-engine.php';
require_once get_template_directory() . '/inc/admin-dashboard.php';
require_once get_template_directory() . '/inc/production-engine.php';
require_once get_template_directory() . '/inc/payment-gateway.php';

/**
 * Install custom database tables for SecondInnings50.
 */
function si50_install_custom_db_tables() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'si50_connect_requests';
	$table_inv = $wpdb->prefix . 'si50_invitation_requests';
	$table_contact = $wpdb->prefix . 'si50_contact_inquiries';
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		sender_id bigint(20) NOT NULL,
		receiver_id bigint(20) NOT NULL,
		status varchar(50) NOT NULL DEFAULT 'pending',
		timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		PRIMARY KEY  (id),
		KEY sender_id (sender_id),
		KEY receiver_id (receiver_id)
	) $charset_collate;";

	$sql_inv = "CREATE TABLE $table_inv (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		email varchar(255) NOT NULL,
		phone varchar(100) NOT NULL,
		gender varchar(50) NOT NULL,
		age_bracket varchar(50) NOT NULL,
		timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	$sql_contact = "CREATE TABLE $table_contact (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		email varchar(255) NOT NULL,
		phone varchar(100) NOT NULL,
		inquiry_nature varchar(255) NOT NULL,
		message text NOT NULL,
		timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	dbDelta( $sql_inv );
	dbDelta( $sql_contact );

	// Trigger production engine tables installation
	si50_install_production_tables();
}
add_action( 'after_switch_theme', 'si50_install_custom_db_tables' );

/**
 * Ensure table is installed if missing during admin initialization.
 */
function si50_check_and_install_db() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'si50_connect_requests';
	$table_audit = $wpdb->prefix . 'si50_audit_logs';
	$table_inv = $wpdb->prefix . 'si50_invitation_requests';
	$table_contact = $wpdb->prefix . 'si50_contact_inquiries';
	$table_reports = $wpdb->prefix . 'si50_member_reports';
	if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name 
		|| $wpdb->get_var( "SHOW TABLES LIKE '$table_audit'" ) !== $table_audit 
		|| $wpdb->get_var( "SHOW TABLES LIKE '$table_inv'" ) !== $table_inv
		|| $wpdb->get_var( "SHOW TABLES LIKE '$table_contact'" ) !== $table_contact
		|| $wpdb->get_var( "SHOW TABLES LIKE '$table_reports'" ) !== $table_reports ) {
		si50_install_custom_db_tables();
	}
}
add_action( 'admin_init', 'si50_check_and_install_db' );

/**
 * Get connection request details between two users.
 */
function si50_get_connection_request( $user_a, $user_b ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'si50_connect_requests';
	$user_a = intval( $user_a );
	$user_b = intval( $user_b );

	return $wpdb->get_row( $wpdb->prepare(
		"SELECT * FROM $table_name 
		 WHERE (sender_id = %d AND receiver_id = %d) 
		    OR (sender_id = %d AND receiver_id = %d) 
		 ORDER BY timestamp DESC LIMIT 1",
		$user_a, $user_b, $user_b, $user_a
	) );
}

/**
 * Get connection request status between two users.
 */
function si50_get_connection_status( $user_a, $user_b ) {
	$row = si50_get_connection_request( $user_a, $user_b );
	return $row ? $row->status : false;
}

/**
 * Check if two users are approved connections.
 */
function si50_are_connected( $user_a, $user_b ) {
	$status = si50_get_connection_status( $user_a, $user_b );
	return ( 'approved' === $status );
}

/**
 * 4. SecondInnings50 Complete Global Meta SEO Optimization Engine
 * Programmatically injects dynamic canonical urls, OpenGraph markup,
 * and optimized descriptions targeted for active Indian seniors and adults.
 */
function si50_seo_meta_tags() {
	global $wp;
	
	// Canonical URL bindings mirroring the active request link
	$canonical_url = home_url( add_query_arg( array(), $wp->request ) );
	if ( is_front_page() || is_home() ) {
		$canonical_url = home_url( '/' );
	}
	
	echo "\n" . '<!-- SecondInnings50 Global SEO Meta Engine -->' . "\n";
	echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";

	// Default OpenGraph parameters
	$og_title     = get_bloginfo( 'name' );
	$og_desc      = get_bloginfo( 'description' );
	$og_type      = 'website';
	$og_site_name = 'SecondInnings50';

	// Map customized tags optimized with keywords for active Indian adults
	if ( is_front_page() || is_home() ) {
		$og_title = esc_html__( 'SecondInnings50 | Premium Companionship & Shared Life Partnerships for 45+', 'secondinnings50' );
		$og_desc  = esc_html__( 'Discover meaningful companionship, friendship, and vetted interest groups for mature adults over 45 in India. A safe, vetted community for active seniors.', 'secondinnings50' );
	} elseif ( is_page( 'about-us' ) || is_page( 'about' ) ) {
		$og_title = esc_html__( 'Our Purpose & Dignified Social Circle | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Learn about SecondInnings50, a dedicated social platform focusing on safety, dignity, security, and companionship for active Indian adults in their silver years.', 'secondinnings50' );
	} elseif ( is_page( 'join-application' ) || is_page( 'join' ) ) {
		$og_title = esc_html__( 'Begin Your New Beginning | Secure Application Gateway | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Join SecondInnings50 today. Secure onboarding and safety verification for companionship, friendship, and meaningful shared partnerships.', 'secondinnings50' );
	} elseif ( is_page( 'directory' ) || is_page( 'members' ) ) {
		$og_title = esc_html__( 'Vetted Senior Directory | Meaningful Connections | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Browse our secure, vetted directory of active adults over 45 seeking companionship, friendship, and shared life partnerships.', 'secondinnings50' );
	} elseif ( is_page( 'profile' ) || is_page( 'my-profile' ) ) {
		$og_title = esc_html__( 'My Profile Settings | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Manage your member profile, update social matching preferences, and view your approved community connections securely.', 'secondinnings50' );
	} elseif ( is_page( 'notifications' ) ) {
		$og_title = esc_html__( 'Connection Invitations & Activity Logs | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Manage incoming connection requests and browse accepted companion status logs securely on your private dashboard.', 'secondinnings50' );
	} elseif ( is_page( 'contact-us' ) || is_page( 'contact' ) ) {
		$og_title = esc_html__( 'Contact Us | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Get in touch with SecondInnings50 support. We are here to help you find meaningful companionship and shared partnerships.', 'secondinnings50' );
	} elseif ( is_page( 'application-received' ) ) {
		$og_title = esc_html__( 'Application Safely Received | SecondInnings50', 'secondinnings50' );
		$og_desc  = esc_html__( 'Your onboarding profile has been safely received. It is undergoing identity verification by our coordination team.', 'secondinnings50' );
	} elseif ( is_page() ) {
		$og_title = get_the_title() . ' | ' . $og_site_name;
		$og_desc  = wp_strip_all_tags( get_the_excerpt() );
		if ( empty( $og_desc ) ) {
			$og_desc = esc_html__( 'SecondInnings50 is the trusted social companion portal designed specifically for active Indian adults.', 'secondinnings50' );
		}
	}

	$site_logo = '';
	if ( has_custom_logo() ) {
		$logo_id = get_theme_mod( 'custom_logo' );
		$logo_data = wp_get_attachment_image_src( $logo_id, 'full' );
		if ( $logo_data ) {
			$site_logo = $logo_data[0];
		}
	}
	if ( empty( $site_logo ) ) {
		$site_logo = esc_url( get_template_directory_uri() . '/assets/hero.jpg' );
	}

	echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $og_desc ) . '">' . "\n";
	echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $canonical_url ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $og_site_name ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $site_logo ) . '">' . "\n";
	
	// Twitter Card Tags
	echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $og_desc ) . '" />' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url( $site_logo ) . '" />' . "\n";

	// Standard metadata tag fallback
	echo '<meta name="description" content="' . esc_attr( $og_desc ) . '">' . "\n";
	echo '<!-- End SecondInnings50 Global SEO Meta Engine -->' . "\n";
}
add_action( 'wp_head', 'si50_seo_meta_tags', 1 );

/**
 * Programmatically filter document title parts for search engines.
 * Overrides layout title details to fit search engine requirements.
 */
function si50_seo_title_parts( $title_parts ) {
	if ( is_front_page() || is_home() ) {
		$title_parts['title']   = esc_html__( 'SecondInnings50 | Premium Companionship & Shared Life Partnerships for 45+', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'about-us' ) || is_page( 'about' ) ) {
		$title_parts['title']   = esc_html__( 'Our Purpose & Dignified Social Community | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'join-application' ) || is_page( 'join' ) ) {
		$title_parts['title']   = esc_html__( 'Begin Your New Beginning | Secure Application Gateway | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'directory' ) || is_page( 'members' ) ) {
		$title_parts['title']   = esc_html__( 'Vetted Senior Directory | Meaningful Connections | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'profile' ) || is_page( 'my-profile' ) ) {
		$title_parts['title']   = esc_html__( 'My Profile Settings | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'notifications' ) ) {
		$title_parts['title']   = esc_html__( 'Notifications | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'contact-us' ) || is_page( 'contact' ) ) {
		$title_parts['title']   = esc_html__( 'Contact Us | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	} elseif ( is_page( 'application-received' ) ) {
		$title_parts['title']   = esc_html__( 'Application Safely Received | SecondInnings50', 'secondinnings50' );
		$title_parts['tagline'] = '';
		$title_parts['site']    = '';
	}
	return $title_parts;
}
add_filter( 'document_title_parts', 'si50_seo_title_parts', 99 );

/**
 * Inject JSON-LD Schema structured data in footer.
 */
function si50_inject_schema_markup() {
	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'SocialGroup',
		'name'        => 'SecondInnings50',
		'url'         => esc_url( home_url( '/' ) ),
		'description' => esc_html__( 'Premium Companionship, friendship interest groups, and shared life partnerships platform for active mature adults over 45 in India.', 'secondinnings50' ),
		'areaServed'  => array(
			'@type' => 'Country',
			'name'  => 'India'
		),
		'audience' => array(
			'@type' => 'Audience',
			'audienceType' => esc_html__( 'Active mature adults, seniors, and retired individuals seeking companions', 'secondinnings50' )
		),
		'knowsAbout' => array(
			esc_html__( 'Senior Companionship', 'secondinnings50' ),
			esc_html__( 'Companionship Interest Groups', 'secondinnings50' ),
			esc_html__( 'Life Partnerships', 'secondinnings50' ),
			esc_html__( 'Senior Social Circles', 'secondinnings50' )
		)
	);

	echo "\n<!-- SecondInnings50 Schema Structured Data -->\n";
	echo '<script type="application/ld+json">' . "\n";
	echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . "\n";
	echo "</script>\n";
}
add_action( 'wp_footer', 'si50_inject_schema_markup' );

/**
 * Dispatch an automated WhatsApp notification.
 * Integrates a clean transactional gateway hook and safe fallback logging.
 */
function si50_send_whatsapp_alert( $to_phone, $message ) {
	if ( empty( $to_phone ) ) {
		error_log( 'SecondInnings50 WhatsApp Error: Recipient phone number is empty.' );
		return false;
	}

	// Clean the phone number (pre-formatted with India country code prefix 91)
	$clean_phone = preg_replace( '/[^0-9]/', '', $to_phone );
	if ( 10 === strlen( $clean_phone ) ) {
		$clean_phone = '91' . $clean_phone;
	}

	// Safe transactional API hook filter
	// Developers can hook into 'si50_whatsapp_api_request' to route to Twilio, Gupshup, etc.
	$payload = array(
		'to'      => $clean_phone,
		'message' => $message,
	);
	
	$payload = apply_filters( 'si50_whatsapp_payload', $payload );

	// Background request with error_log fallback to prevent timeout failures
	// For simulation/production routing, we log to PHP error log as requested.
	error_log( sprintf( '🔔 [WhatsApp Outgoing SMS] To: +%s, Message: "%s"', $clean_phone, $message ) );

	// Standard transactional API request (e.g. wp_safe_remote_post to a WhatsApp Fiduciary API)
	$api_url = si50_resolve_credential( 'SI50_WHATSAPP_API_URL', 'whatsapp_api_url', false );
	if ( ! empty( $api_url ) ) {
		wp_remote_post( $api_url, array(
			'method'      => 'POST',
			'timeout'     => 5,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => false, // async background processing
			'headers'     => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . si50_get_whatsapp_api_key()
			),
			'body'        => json_encode( $payload ),
		) );
	}

	return true;
}






