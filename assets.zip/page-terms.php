<?php
/**
 * Template Name: Terms of Service Template
 *
 * @package SecondInnings50
 */

get_header();
?>

<main id="main-content" class="site-main content-area" style="background-color: #F8F9FA; min-height: 80vh; padding: 40px 0; box-sizing: border-box;">
  <!-- Google Developer Editorial Page Container -->
  <div class="si50-legal-container" style="max-width: 800px; margin: 0 auto; padding: 60px 30px; font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif; color: #333333; line-height: 1.8; background: #FFFFFF; border: 1px solid #E0E0E0; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.02); box-sizing: border-box;">
    
    <style>
      .si50-legal-container h1, .si50-legal-container h2, .si50-legal-container h3 {
        font-family: 'Playfair Display', Georgia, serif;
        color: #23282d;
        margin-top: 1.5em;
        margin-bottom: 0.5em;
        font-weight: 700;
      }
      .si50-legal-container h1 {
        font-size: 2.25rem;
        margin-top: 0;
        border-bottom: 2px solid #E0E0E0;
        padding-bottom: 15px;
      }
      .si50-legal-container h2 {
        font-size: 1.5rem;
        border-bottom: 1px solid #E0E0E0;
        padding-bottom: 8px;
        margin-top: 2em;
      }
      .si50-legal-container h3 {
        font-size: 1.2rem;
        color: #374151;
      }
      .si50-legal-container p {
        margin-bottom: 1.25em;
        font-size: 1.05rem;
      }
      .si50-legal-container ul, .si50-legal-container ol {
        margin-bottom: 1.5em;
        padding-left: 20px;
      }
      .si50-legal-container li {
        margin-bottom: 0.5em;
        font-size: 1.025rem;
      }
      .si50-legal-container .meta-info {
        font-size: 0.9rem;
        color: #666666;
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        border-bottom: 1px solid #E0E0E0;
        padding-bottom: 12px;
      }
      .si50-legal-container .disclaimer-box {
        background-color: #FEF2F2;
        border-left: 4px solid #EF4444;
        padding: 20px;
        margin: 25px 0;
        border-radius: 4px;
      }
      .si50-legal-container .disclaimer-box h4 {
        margin-top: 0;
        color: #991B1B;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 8px;
      }
      .si50-legal-container .disclaimer-box p {
        margin-bottom: 0;
        font-size: 0.975rem;
        color: #7F1D1D;
      }
      .si50-legal-container .guidelines-section {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        padding: 30px;
        border-radius: 6px;
        margin-top: 40px;
      }
      .si50-legal-container .guidelines-section h2 {
        margin-top: 0;
        border-bottom: 2px solid #CBD5E1;
        color: #1E293B;
      }
      .si50-back-btn {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 24px;
        background-color: #23282d;
        color: #FFFFFF !important;
        text-decoration: none;
        border-radius: 4px;
        font-weight: 600;
        font-size: 0.95rem;
        transition: background-color 0.2s ease-in-out;
      }
      .si50-back-btn:hover {
        background-color: #4A5568;
      }
      @media (max-width: 600px) {
        .si50-legal-container {
          padding: 30px 20px;
          border-radius: 0;
          border-left: none;
          border-right: none;
        }
        .si50-legal-container h1 {
          font-size: 1.75rem;
        }
        .si50-legal-container h2 {
          font-size: 1.35rem;
        }
      }
    </style>

    <h1><?php esc_html_e( 'SecondInnings50 Terms of Service', 'secondinnings50' ); ?></h1>
    
    <div class="meta-info">
      <span><?php esc_html_e( 'Scope: Indian Senior Community Platform', 'secondinnings50' ); ?></span>
      <span><strong><?php esc_html_e( 'Last Updated:', 'secondinnings50' ); ?></strong> <?php echo date( 'F d, Y' ); ?></span>
    </div>

    <p>
      <?php esc_html_e( 'Welcome to SecondInnings50. These Terms of Service ("Terms") govern your access to and use of our platform, services, circles, and offline meetup networks. By submitting a registration request, participating in our telephone onboarding, or using our directory, you agree to comply with and be bound by these Terms.', 'secondinnings50' ); ?>
    </p>

    <h2><?php esc_html_e( '1. Membership Eligibility & Verification Gate', 'secondinnings50' ); ?></h2>
    <p>
      <?php esc_html_e( 'SecondInnings50 is an exclusive social network curated specifically for active, mature adults. Registration is strictly limited to individuals who are 45 years of age and older. By applying, you represent that you meet this age requirement.', 'secondinnings50' ); ?>
    </p>
    <p>
      <?php esc_html_e( 'To preserve the safety and high standards of our ecosystem, every applicant is subject to manual administrative vetting. This includes an identity verification check and a structured telephone onboarding session with a community host. We reserve the absolute right to approve, reject, or suspend any application or account registration request without disclosing the underlying administrative justification.', 'secondinnings50' ); ?>
    </p>

    <h2><?php esc_html_e( '2. Profile Preference Synchronization & Database Updates', 'secondinnings50' ); ?></h2>
    <p>
      <?php esc_html_e( 'Our platform operates a real-time matching model. When you edit your profile details, including residing city, companion styles, bio notes, or interest circles, these changes immediately write and synchronize across our secure server databases. You are solely responsible for ensuring that all data in your profile is accurate, truthful, and representative of your identity. False representations (catfishing) will result in account suspension.', 'secondinnings50' ); ?>
    </p>

    <!-- Offline Safe Harbor & Liability Disclaimer -->
    <div class="disclaimer-box">
      <h4>⚠️ <?php esc_html_e( 'Offline Interaction Safe Harbor & Liability Disclaimer', 'secondinnings50' ); ?></h4>
      <p>
        <strong><?php esc_html_e( 'PLEASE READ CAREFULLY:', 'secondinnings50' ); ?></strong> 
        <?php esc_html_e( 'SecondInnings50 provides peer-connection matching utilities, interest circles, and local meetup directories. We act strictly as an online connector to introduce verified members. The platform does not organize, sponsor, underwrite, or assume liability for individual meetups, offline interactions, private activity arrangements, or joint plans initiated by members. We explicitly disclaim any liability for personal disputes, financial arrangements, safety concerns, physical injury, or conduct occurring during offline city meetups, external chats, or self-organized activities. All offline arrangements are undertaken entirely at your own risk.', 'secondinnings50' ); ?>
      </p>
    </div>

    <h2><?php esc_html_e( '3. Matched Handshake and Contact Masking', 'secondinnings50' ); ?></h2>
    <p>
      <?php esc_html_e( 'By utilizing our directory and sending connection requests, you agree that your contact information (WhatsApp number and email) will only be made visible to another member when a mutual connection handshake is successfully established. You agree to use the contact details shared via this handshake solely for respectful, personal interactions and not for commercial advertising or marketing.', 'secondinnings50' ); ?>
    </p>

    <!-- Integrated Community Guidelines Layout Section -->
    <div id="community-guidelines" class="guidelines-section">
      <h2><?php esc_html_e( 'SecondInnings50 Community Guidelines', 'secondinnings50' ); ?></h2>
      <p>
        <?php esc_html_e( 'To ensure that our community remains a premium, secure, and honorable sanctuary for active adults, all members must strictly adhere to the following codes of conduct. Violation of these guidelines will result in immediate, non-refundable account termination.', 'secondinnings50' ); ?>
      </p>

      <h3><?php esc_html_e( 'A. Respectful & Dignified Communication', 'secondinnings50' ); ?></h3>
      <ul>
        <li><?php esc_html_e( 'Treat every community member, coordinator, and host with utmost dignity and respect.', 'secondinnings50' ); ?></li>
        <li><?php esc_html_e( 'We maintain a strict zero-tolerance policy towards harassment, abusive language, discrimination, catfishing, or unwanted romantic advancements.', 'secondinnings50' ); ?></li>
        <li><?php esc_html_e( 'Respect personal boundaries. If a member does not accept your connection request, or asks you to stop contacting them, you must immediately cease all communication.', 'secondinnings50' ); ?></li>
      </ul>

      <h3><?php esc_html_e( 'B. Zero Commercial Spamming & WhatsApp Broadcasting Rules', 'secondinnings50' ); ?></h3>
      <ul>
        <li><?php esc_html_e( 'You must not use personal contact details obtained via the Handshake Protocol to send unsolicited promotions, forward chain messages, commercial solicitations, or financial multi-level marketing (MLM) invitations.', 'secondinnings50' ); ?></li>
        <li><?php esc_html_e( 'Creating external WhatsApp groups or broadcasting lists containing SecondInnings50 members for commercial purposes, business networking, or advertising is strictly forbidden.', 'secondinnings50' ); ?></li>
        <li><?php esc_html_e( 'Any member reported for spamming, selling services, or broadcasting marketing content inside external chats will be banned instantly.', 'secondinnings50' ); ?></li>
      </ul>

      <h3><?php esc_html_e( 'C. Safe Meetup Organizing & Activity Planning', 'secondinnings50' ); ?></h3>
      <p>
        <?php esc_html_e( 'When coordinating a local meetup, face-to-face tea meeting, or activity circle with a peer, prioritize your personal security by adhering to the following guidelines:', 'secondinnings50' ); ?>
      </p>
      <ul>
        <li>
          <strong><?php esc_html_e( 'Public Meetups First:', 'secondinnings50' ); ?></strong> 
          <?php esc_html_e( 'Always meet new members in a public space (such as a local cafe, park, or restaurant) for the first few interactions before visiting each other\'s homes or planning private gatherings.', 'secondinnings50' ); ?>
        </li>
        <li>
          <strong><?php esc_html_e( 'Financial Independence:', 'secondinnings50' ); ?></strong> 
          <?php esc_html_e( 'Do not pool funds, prepay for services through another member\'s personal account, or lend money. Handle all activity costs and reservations independently.', 'secondinnings50' ); ?>
        </li>
        <li>
          <strong><strong><?php esc_html_e( 'Share Meeting Details:', 'secondinnings50' ); ?></strong></strong> 
          <?php esc_html_e( 'Before meeting a new member offline, share the meeting location, time, and the peer\'s verified profile name with your family, children, or a close friend.', 'secondinnings50' ); ?>
        </li>
      </ul>
    </div>

    <h2><?php esc_html_e( '4. Amendments & Governing Law', 'secondinnings50' ); ?></h2>
    <p>
      <?php esc_html_e( 'We reserve the right to modify these Terms and our Community Guidelines at any time. Your continued use of the platform following any update constitutes acceptance of the modified Terms. These Terms are governed by and construed in accordance with the laws of India, and any disputes shall be subject to the exclusive jurisdiction of the courts of Mumbai, Maharashtra.', 'secondinnings50' ); ?>
    </p>

    <div style="border-top: 1px solid #E0E0E0; margin-top: 40px; padding-top: 20px; text-align: center;">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="si50-back-btn">
        <?php esc_html_e( 'Return to SecondInnings50', 'secondinnings50' ); ?>
      </a>
    </div>

  </div>
</main>

<?php
get_footer();
